exports.PORT = 3000;
exports.DB_QUERY_STRING = 'mongodb://localhost:27017/cryptoTrade';
exports.SALT_ROUNDS = 10;
exports.SECRET = 'Mysupersecret';
exports.SESSION_NAME = 'user_session';
